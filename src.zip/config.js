// Configuration file for the bot
module.exports = {
    prefix: process.env.PREFIX || '!',
    defaultCooldown: 3, // Default cooldown in seconds
    developers: process.env.DEVELOPERS ? process.env.DEVELOPERS.split(',') : [],
    permissions: {
        administrator: 'Administrator',
        manageServer: 'Manage Server',
        manageRoles: 'Manage Roles',
        manageChannels: 'Manage Channels',
        kickMembers: 'Kick Members',
        banMembers: 'Ban Members',
        moderateMembers: 'Moderate Members'
    },
    colors: {
        primary: '#007bff',
        success: '#28a745',
        danger: '#dc3545',
        warning: '#ffc107',
        info: '#17a2b8'
    },
    automod: {
        enabled: true,
        // Words that should be filtered by the automod system
        filteredWords: process.env.FILTERED_WORDS ? process.env.FILTERED_WORDS.split(',') : [],
        // Maximum allowed mentions in a single message
        maxMentions: 5,
        // Action to take when automod is triggered: 'delete', 'warn', 'mute', or 'kick'
        action: 'delete'
    },
    muteRole: process.env.MUTE_ROLE || 'Muted',
    logChannel: process.env.LOG_CHANNEL || 'mod-logs'
};
